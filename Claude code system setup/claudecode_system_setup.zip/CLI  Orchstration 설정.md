# CLI Orchestration 설정 가이드
#claude-code #orchestration #multi-agent #cli

> 최종 업데이트: 2026-03-18
> Claude Code: v2.1.78 | 설정: .claude/settings.json

## 🎯 개요

CLI Orchestration은 여러 에이전트를 조율하여 복잡한 작업을 자동화하는 시스템입니다.
Claude Code v2.1.78은 `cli-orchestrator`와 `Primary Coordinator` 내장 에이전트를 제공합니다.

## 📋 내장 오케스트레이션 에이전트

### 1. cli-orchestrator
멀티 목적 CLI 오케스트레이션 에이전트:
- 여러 에이전트를 조율하는 복잡한 작업
- CLI 도구의 순차/병렬 실행 (빌드→테스트→배포)
- 새 프로젝트 자동 부트스트래핑

**사용 시기**: "orchestrate", "pipeline", "bootstrap", "병렬 실행", "여러 에이전트" 등의 키워드

**가용 도구**: Bash, Read, Write, Edit, Glob, Grep, Task, TodoWrite

### 2. Primary Coordinator
멀티 에이전트 워크플로우 조율자 (ACE Layer 4 - Executive Function):
- 복잡한 작업의 전략적 분해
- 공유 리소스 충돌 해결
- 윤리적 검증 게이트

**사용 시기**: "coordinate", "orchestrate agents", "multi-agent" 등의 키워드

**가용 도구**: Bash, Read, Write, Edit, Glob, Grep, Task, TodoWrite

## 🏗️ ACE Framework 레이어 구조

오케스트레이션은 ACE (Autonomous Cognitive Entity) Framework의 6개 레이어를 따릅니다:

```
Layer 1: ASPIRATIONAL       - 윤리적 원칙과 제약
Layer 2: GLOBAL STRATEGY     - 전체 미션과 장기 목표
Layer 3: AGENT MODEL        - 자기 인식 (능력/한계)
Layer 4: EXECUTIVE FUNCTION  - 작업 분해와 리소스 배분 ← Primary Coordinator
Layer 5: COGNITIVE CONTROL   - 작업 선택과 충돌 방지
Layer 6: TASK PROSECUTION    - 실제 실행 (도구/스킬 사용)
```

## 🚀 오케스트레이션 패턴

### 패턴 1: 순차 파이프라인
```bash
# 빌드 → 테스트 → 배포 순차 실행
claude "Orchestrate: build the project, run all tests, then deploy to staging"
```

### 패턴 2: 병렬 분석
```bash
# 여러 분석을 동시 실행
claude "In parallel:
1. Run security audit on the codebase
2. Analyze performance bottlenecks
3. Check code coverage
Then combine results into a single report"
```

### 패턴 3: 설계→구현→검증
```bash
# 멀티 에이전트 협업
claude "Coordinate these agents:
1. Plan agent: Design the API architecture
2. code-architect: Define data models
3. feature-dev: Implement endpoints
4. verify-agent: Run build and test verification"
```

### 패턴 4: Worktree 격리 병렬 작업
```bash
# 독립적인 작업을 격리된 환경에서 동시 실행
claude "Execute in parallel with worktree isolation:
1. Refactor the auth module
2. Add new payment endpoints
Each should run tests independently before returning"
```

## ⚙️ 설정 방법

### 글로벌 설정 (~/.claude/settings.json)
```json
{
  "permissions": {
    "allow": [
      "Bash(npm *)",
      "Bash(git *)",
      "Bash(docker *)"
    ]
  }
}
```

### 프로젝트 설정 (.claude/settings.json)
```json
{
  "hooks": {
    "SubagentStop": [
      {
        "hooks": [{
          "type": "command",
          "command": "echo 'Agent completed: $AGENT_NAME'"
        }]
      }
    ]
  }
}
```

## 📊 실전 활용 예시

### 프로젝트 부트스트래핑
```bash
claude "Bootstrap a new Next.js 15 project with:
- TypeScript configuration
- Tailwind CSS setup
- ESLint + Prettier
- Vitest for testing
- Playwright for E2E
- GitHub Actions CI/CD
- Docker configuration
- CLAUDE.md with project context"
```

### 릴리스 파이프라인
```bash
claude "Execute release pipeline:
1. Run full test suite
2. Build production bundle
3. Generate changelog from commits
4. Create GitHub release
5. Deploy to staging
6. Run smoke tests
Report results at each step"
```

### 코드베이스 분석
```bash
claude "Analyze the entire codebase:
- Architecture overview (use Explore agent, very thorough)
- Security vulnerabilities (use code-reviewer)
- Performance hotspots (use code-explorer)
- Test coverage gaps (use test-runner)
Compile findings into a comprehensive report"
```

## 🔗 참고 자료

- [Parallel Agents Safety Protocol v3.1.0](Parallel%20Agents%20Safety%20Protocol%20v3.1.0.md)
- [Agent Teams 공식 문서](https://code.claude.com/docs/ko/agent-teams)
- [Multi-Agent Research System](https://www.anthropic.com/engineering/multi-agent-research-system)

---

*CLI Orchestration은 복잡한 워크플로우를 자동화하는 강력한 도구입니다.*
*마지막 업데이트: 2026-03-18 | Claude Code v2.1.78*

#orchestration #multi-agent #cli #automation