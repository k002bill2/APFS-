# Claude Code 통합 시스템 구축 프롬프트
## Parallel Agents + Skills 활성화 + Dev Docs 통합

---

## 📋 사용법

아래 프롬프트를 Claude Code CLI에 그대로 붙여넣으세요.
참조 파일이 반드시 같은 디렉토리에 위치해야 합니다:

```
your-project/
└── Parallel_Agents_Safety_Protocol_v3_1_0.md  ← 이 파일 필요
```

---

## 🚀 Claude Code에 입력할 프롬프트

```
첨부 파일 `Parallel_Agents_Safety_Protocol_v3_1_0.md`를 완전히 읽고,
아래 명세에 따라 Claude Code 통합 시스템을 구축해줘.

이 시스템은 3대 핵심 시스템을 한번에 구축합니다:
  A. Parallel Agents (멀티에이전트 안전 프로토콜)
  B. Skills 자동 활성화 (Hook 기반 스킬 강제 적용)
  C. Dev Docs (대규모 작업 컨텍스트 관리)

---

## 📌 사전 지시사항

1. 작업 시작 전 파일을 반드시 먼저 끝까지 읽어라 (view tool 사용)
2. pseudocode / TypeScript 예시 코드는 "구현 참조용"이므로 실제 파일로 생성하지 마라
3. 모든 파일 생성 전 디렉토리가 없으면 먼저 생성하라
4. 완료 후 반드시 생성된 파일 목록과 구조를 보고하라
5. 모델 string은 문서의 표기와 무관하게 실제 API string을 사용하라:
   - opus → claude-opus-4-5
   - sonnet → claude-sonnet-4-5
   - haiku → claude-haiku-4-5
6. Hook command는 bash 스크립트(.sh)로 작성하라 (node/ts 아님)
7. settings.json은 하나의 파일에 모든 시스템의 hooks를 통합하라

---

## 🏗️ 생성할 파일 목록 (순서대로)

═══════════════════════════════════════
## PART A: Parallel Agents 시스템
═══════════════════════════════════════

### STEP 1: 설정 파일 (통합)

**파일**: `.claude/settings.json`
**근거**: 프로토콜 Appendix A6 + Skills 활성화 + Dev Docs hooks
**내용 요구사항**:
- permissions.allow / deny 섹션 (Appendix A6 기준)
- model: "claude-sonnet-4-5"
- maxTokens: 16000

hooks 섹션은 아래 3개 시스템을 모두 통합:

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "matcher": "",
        "hooks": [{
          "type": "command",
          "command": "bash .claude/hooks/skill-activator.sh \"$PROMPT\""
        }]
      }
    ],
    "PreToolUse": [],
    "PostToolUse": [],
    "PreCompact": [
      {
        "matcher": "",
        "hooks": [{
          "type": "command",
          "command": "echo '[DEV-DOCS] ⚠️ Context compaction imminent - save progress to dev docs!'"
        }]
      }
    ],
    "PostCompact": [
      {
        "matcher": "",
        "hooks": [{
          "type": "command",
          "command": "bash .claude/hooks/post-compact-reminder.sh"
        }]
      }
    ],
    "Stop": [],
    "StopFailure": [],
    "Notification": [],
    "SessionStart": [],
    "SessionEnd": [],
    "SubagentStop": [],
    "Elicitation": []
  }
}
```

---

### STEP 2: Agent 파일들

모든 agent 파일의 공통 규칙:
- 저장 위치: `.claude/agents/`
- 파일 형식: Markdown with YAML frontmatter
- frontmatter 필수 필드: name, description, model, effort, maxTurns, disallowedTools
- System Prompt는 한국어/영어 병행 작성

---

**파일**: `.claude/agents/primary-coordinator.md`
**근거**: 문서 Section 3.1 + Section 2.5 (Agent Hierarchy) + Appendix A4
**frontmatter**:
- model: claude-opus-4-5
- effort: high
- maxTurns: 50
- disallowedTools: ["Bash(rm -rf *)", "Bash(sudo *)"]
**System Prompt 포함 내용**:
- ACE Layer 4 (Executive Function) 역할 정의
- 태스크 분해 및 Secondary Agent 배분 프로세스
- Dynamic Reallocation 트리거 조건 (30% 이탈 시)
- 파일 Lock 획득/해제 절차 (Section 4.1 기반)
- Secondary Agent 결과물 검증 후 present_files 사용 원칙
- SendMessage 패턴으로 실행 중 에이전트와 통신하는 방법
- 에러 발생 시 사용자에게 보고하는 형식 (Section 9.2 예시 참조)
- 윤리적 우려 발생 시 즉시 중단 후 사용자에게 알리는 절차

---

**파일**: `.claude/agents/code-explorer.md`
**근거**: 문서 내장 에이전트 타입 `feature-dev:code-explorer` + Section 3.2
**frontmatter**:
- model: claude-sonnet-4-5
- effort: medium
- maxTurns: 30
- disallowedTools: ["Bash(rm *)", "Bash(sudo *)", "Write"]
**System Prompt 포함 내용**:
- ACE Layer 6 (Task Prosecution) 역할 정의
- 코드베이스 분석 및 탐색 전문 에이전트임을 명시
- Read-only 원칙: 파일 수정 불가, 분석/보고만 수행
- 능력 초과 태스크 수신 시 Primary에 즉시 에스컬레이션
- 분석 결과 보고 형식 (Section 5.1 status reporting format 참조)

---

**파일**: `.claude/agents/code-reviewer.md`
**근거**: 문서 내장 에이전트 타입 `feature-dev:code-reviewer` + Section 3.2
**frontmatter**:
- model: claude-sonnet-4-5
- effort: high
- maxTurns: 30
- disallowedTools: ["Bash(rm *)", "Bash(sudo *)"]
**System Prompt 포함 내용**:
- ACE Layer 5 (Cognitive Control) + Layer 6 역할
- 코드 리뷰 전문: 보안, 성능, 가독성, 아키텍처 관점
- Cross-Agent Verification 역할 수행 (Section 8.2 기반)
- Critical 이슈 발견 시 Ethical Veto 발동 절차
- 리뷰 결과 보고 형식 (LGTM / Minor / Major / Critical 분류)

---

**파일**: `.claude/agents/verify-agent.md`
**근거**: 문서 내장 에이전트 타입 `verify-agent` + Section 8 (Validation and QA)
**frontmatter**:
- model: claude-sonnet-4-5
- effort: high
- maxTurns: 20
- disallowedTools: ["Bash(rm *)", "Bash(sudo *)"]
**System Prompt 포함 내용**:
- Fresh context에서 독립적으로 빌드/테스트 검증 수행
- Pre/Mid/Post Execution Validation 체크리스트 (Section 8.1) 수행
- 검증 실패 시 Primary에 즉시 에스컬레이션
- 파일 무결성 검증 (checksum 방식) 수행
- 검증 결과 PASS / WARN / FAIL 형식으로 보고

---

**파일**: `.claude/agents/code-architect.md`
**근거**: 문서 내장 에이전트 타입 `feature-dev:code-architect`
**frontmatter**:
- model: claude-opus-4-5
- effort: high
- maxTurns: 40
- disallowedTools: ["Bash(rm -rf *)", "Bash(sudo *)"]
**System Prompt 포함 내용**:
- 시스템 아키텍처 설계 전문 에이전트
- 구현 전 설계 검토, 의존성 분석, 리스크 평가
- Primary Coordinator와 협력하여 태스크 분해 전략 수립
- 아키텍처 결정 사항 문서화 및 Primary 승인 요청

---

### STEP 3: CLAUDE.md (프로젝트 루트)

**파일**: `CLAUDE.md`
**요구사항**: 120줄 이내로 핵심만 요약. 전체 프로토콜 내용을 복붙하지 말 것.
**포함할 섹션**:

1. **시스템 개요** (3줄): 이 프로젝트의 멀티에이전트 프로토콜 버전과 목적
2. **Agent 역할 요약표** (간단한 마크다운 테이블):
   - primary-coordinator / code-explorer / code-reviewer / verify-agent / code-architect
   - 각각의 한 줄 역할 설명
3. **핵심 안전 원칙** (5개 이내 bullet):
   - Data Integrity 우선
   - Secondary Agent는 Primary 승인 없이 공유 파일 수정 불가
   - 윤리적 우려 발생 시 즉시 중단
   - 능력 초과 태스크는 즉시 에스컬레이션
   - 파일 생성/편집 전 반드시 해당 SKILL.md 먼저 읽기
4. **Agent 실행 패턴 치트시트**:
   - run_in_background 패턴
   - worktree isolation 패턴
   - SendMessage 패턴
5. **Dev Docs 워크플로우**:
   - /dev-docs → 구현 → /update-dev-docs → /compact 사이클
   - dev/active/[task-name]/ 3-파일 구조 설명
6. **Skills 활성화**:
   - UserPromptSubmit hook으로 자동 스킬 매칭
   - skill-rules.json에서 트리거 규칙 관리
7. **전체 프로토콜 참조**: `docs/Parallel_Agents_Safety_Protocol_v3_1_0.md`

---

### STEP 4: 문서 보관

**작업**: 원본 프로토콜 파일을 `docs/` 디렉토리로 복사

```
docs/Parallel_Agents_Safety_Protocol_v3_1_0.md
```

---

═══════════════════════════════════════
## PART B: Skills 자동 활성화 시스템
═══════════════════════════════════════

### STEP 5: Skills 트리거 규칙

**파일**: `.claude/hooks/skill-rules.json`
**목적**: 모든 스킬의 트리거 키워드와 의도 패턴 정의
**내용**:
```json
{
  "rules": [
    {
      "skillName": "code-reviewer",
      "priority": "high",
      "enforcement": "suggest",
      "keywords": ["review", "PR", "코드 리뷰", "검토"],
      "intentPatterns": ["(review|check|audit).*?(code|PR|changes)"]
    },
    {
      "skillName": "frontend-dev-guidelines",
      "priority": "high",
      "enforcement": "suggest",
      "keywords": ["react", "component", "hooks", "state", "UI", "frontend"],
      "intentPatterns": ["(create|build|make).*?(component|page|screen)"]
    },
    {
      "skillName": "backend-dev-guidelines",
      "priority": "high",
      "enforcement": "suggest",
      "keywords": ["backend", "controller", "service", "API", "endpoint"],
      "intentPatterns": ["(create|add).*?(route|endpoint|controller)"]
    },
    {
      "skillName": "database-verification",
      "priority": "critical",
      "enforcement": "block",
      "keywords": ["database", "migration", "schema", "prisma"],
      "intentPatterns": [".*?(alter|modify|change|drop).*?table"]
    }
  ]
}
```

**주의**: 위는 예시 규칙이다. 프로젝트에 실제 `.claude/skills/` 디렉토리가 있다면,
그 스킬들을 기반으로 규칙을 생성하라. 없다면 위 예시를 기본값으로 사용하라.

---

### STEP 6: Skills 활성화 Hook 스크립트

**파일**: `.claude/hooks/skill-activator.sh`
**목적**: UserPromptSubmit에서 실행. 프롬프트를 분석하여 관련 스킬 추천
**동작**:
1. skill-rules.json을 읽는다
2. 입력된 프롬프트($1)에서 키워드 매칭
3. 매칭된 스킬을 priority 순으로 정렬
4. 결과를 stdout으로 출력 (Claude가 system-reminder로 수신)

**스크립트 구조**:
```bash
#!/bin/bash
# Skills Auto-Activator
# Usage: skill-activator.sh "$PROMPT"

PROMPT="$1"
RULES_FILE="$(dirname "$0")/skill-rules.json"

if [ ! -f "$RULES_FILE" ]; then
  exit 0
fi

# jq로 키워드 매칭 (jq 없으면 grep 대체)
MATCHED=""

if command -v jq &>/dev/null; then
  MATCHED=$(jq -r --arg prompt "$PROMPT" '
    .rules[] |
    select(
      (.keywords[] | ascii_downcase) as $kw |
      ($prompt | ascii_downcase | contains($kw))
    ) |
    "\(.priority | ascii_upcase): \(.skillName)"
  ' "$RULES_FILE" 2>/dev/null | sort -u)
fi

if [ -n "$MATCHED" ]; then
  echo "[SKILLS ACTIVATED]"
  echo "$MATCHED"
fi
```

**주의**: 스크립트에 실행 권한(chmod +x)을 부여하라.

---

### STEP 7: Post-Compact 리마인더 스크립트

**파일**: `.claude/hooks/post-compact-reminder.sh`
**목적**: PostCompact에서 실행. 컨텍스트 압축 후 사용 가능한 스킬과 Dev Docs 상태 안내
**스크립트 구조**:
```bash
#!/bin/bash
# Post-Compaction Reminder

echo "[POST-COMPACT REMINDER]"

# 사용 가능한 스킬 목록
if [ -d ".claude/skills" ]; then
  SKILLS=$(ls -d .claude/skills/*/ 2>/dev/null | xargs -I{} basename {})
  if [ -n "$SKILLS" ]; then
    echo "Available skills: $SKILLS"
  fi
fi

# 활성 Dev Docs 확인
if [ -d "dev/active" ]; then
  ACTIVE=$(ls dev/active/ 2>/dev/null)
  if [ -n "$ACTIVE" ]; then
    echo "Active dev docs: $ACTIVE"
    echo "Run: 'Continue from dev docs' to resume work"
  fi
fi
```

**주의**: 스크립트에 실행 권한(chmod +x)을 부여하라.

---

═══════════════════════════════════════
## PART C: Dev Docs 시스템
═══════════════════════════════════════

### STEP 8: Dev Docs 디렉토리 구조

**작업**: 아래 디렉토리를 생성하라 (파일 없이 디렉토리만)
```
dev/
├── active/        # 진행 중인 작업
└── completed/     # 완료된 작업 아카이브
```

빈 디렉토리가 git에서 추적되도록 각 디렉토리에 `.gitkeep` 파일을 생성하라.

---

### STEP 9: Dev Docs Custom Commands

**파일**: `.claude/commands/dev-docs.md`
**내용**:
```markdown
---
description: Create comprehensive dev docs for approved plan
---

Based on the approved plan, create three development documents:

1. Create `dev/active/$ARGUMENTS/[task-name]-plan.md`
   - Copy the full approved plan
   - Add timeline and phases
   - Include success metrics

2. Create `dev/active/$ARGUMENTS/[task-name]-context.md`
   - List all relevant files
   - Document key architectural decisions
   - Note any constraints or dependencies
   - Add "Next Steps" section
   - Timestamp: current date

3. Create `dev/active/$ARGUMENTS/[task-name]-tasks.md`
   - Convert plan into detailed checklist
   - Group by component/service
   - Use checkbox format [ ] / [x]
   - Add completion counts per section

$ARGUMENTS is the task name (e.g., user-dashboard).
If not provided, ask the user for the task name.
```

---

**파일**: `.claude/commands/update-dev-docs.md`
**내용**:
```markdown
---
description: Update dev docs before context compaction or session end
---

Find the active dev docs in `dev/active/` and update:

1. **context.md**:
   - Update "Last Updated" timestamp
   - Add any new decisions made this session
   - Update "Current Issues" section
   - Revise "Next Steps" based on progress

2. **tasks.md**:
   - Mark completed items with [x]
   - Add any new tasks discovered
   - Update completion counts
   - Reorder by priority if needed

3. **Add session summary** (append to context.md):
   - What was accomplished
   - Any blockers encountered
   - Critical next actions

Keep updates concise but comprehensive.
```

---

**파일**: `.claude/commands/resume.md`
**내용**:
```markdown
---
description: Resume work from dev docs after session restart or compaction
---

Resume the current development task:

1. Find active task in `dev/active/`
2. Read all three files:
   - plan.md → understand the overall plan
   - context.md → understand current state and decisions
   - tasks.md → identify next uncompleted tasks
3. Summarize:
   - Overall progress (X/Y tasks complete)
   - What was last worked on
   - What should be done next
4. Ask user to confirm the next steps before proceeding

If multiple active tasks exist, list them and ask which to resume.
```

---

**파일**: `.claude/commands/save-and-compact.md`
**내용**:
```markdown
---
description: Save context to dev docs and run /compact
---

Before compaction, save all progress:

1. Run the /update-dev-docs workflow (update context.md, tasks.md)
2. Save any important decisions or learnings to memory if applicable
3. Confirm save is complete
4. Then run /compact

This ensures no context is lost during compaction.
```

---

## ✅ 완료 조건

모든 파일 생성 후 아래 형식으로 보고하라:

```
## 통합 시스템 구축 완료 보고

### PART A: Parallel Agents
.claude/
├── settings.json              ✅  (통합 hooks 포함)
└── agents/
    ├── primary-coordinator.md     ✅
    ├── code-explorer.md           ✅
    ├── code-reviewer.md           ✅
    ├── verify-agent.md            ✅
    └── code-architect.md          ✅
CLAUDE.md                      ✅  (3대 시스템 요약)
docs/
└── Parallel_Agents_Safety_Protocol_v3_1_0.md  ✅

### PART B: Skills 자동 활성화
.claude/hooks/
├── skill-rules.json               ✅
├── skill-activator.sh             ✅  (chmod +x)
└── post-compact-reminder.sh       ✅  (chmod +x)

### PART C: Dev Docs
dev/
├── active/.gitkeep                ✅
└── completed/.gitkeep             ✅
.claude/commands/
├── dev-docs.md                    ✅
├── update-dev-docs.md             ✅
├── resume.md                      ✅
└── save-and-compact.md            ✅

### 주의사항 / 조정 사항
(문서와 실제 Claude Code API 간 불일치 발견 시 여기에 기록)
(hooks command format 검증 결과 기록)

### 다음 권장 작업
1. Skills 디렉토리에 프로젝트별 스킬 추가: .claude/skills/[skill-name]/SKILL.md
2. skill-rules.json에 실제 스킬 트리거 규칙 추가
3. 테스트: "Create a React component" 프롬프트로 스킬 활성화 확인
4. 테스트: /dev-docs my-feature 로 Dev Docs 생성 확인
5. 멀티에이전트 테스트: 간단한 2-에이전트 태스크 실행
```

---

## ⚠️ 주의사항 (작업 중 확인할 것)

- `SendMessage`, `isolation: "worktree"`, `run_in_background` 등 v3.1.0 신규 API는
  현재 Claude Code 버전에서 지원 여부를 먼저 확인하고, 미지원 시 주석으로 표시할 것
- settings.json의 hooks command는 반드시 실행 가능한 경로를 사용할 것
- hook 스크립트(.sh)에 반드시 chmod +x 실행 권한 부여
- agent frontmatter의 model string은 실제 API string 기준으로 작성
- Dev Docs 명령어의 $ARGUMENTS는 Claude Code가 자동으로 치환하는 변수임
- jq가 설치되지 않은 환경에서도 skill-activator.sh가 에러 없이 동작하도록 방어 처리
```

---

## 📁 예상 최종 디렉토리 구조

```
your-project/
├── CLAUDE.md
├── .claude/
│   ├── settings.json
│   ├── agents/
│   │   ├── primary-coordinator.md
│   │   ├── code-explorer.md
│   │   ├── code-reviewer.md
│   │   ├── verify-agent.md
│   │   └── code-architect.md
│   ├── hooks/
│   │   ├── skill-rules.json
│   │   ├── skill-activator.sh
│   │   └── post-compact-reminder.sh
│   └── commands/
│       ├── dev-docs.md
│       ├── update-dev-docs.md
│       ├── resume.md
│       └── save-and-compact.md
├── dev/
│   ├── active/.gitkeep
│   └── completed/.gitkeep
└── docs/
    └── Parallel_Agents_Safety_Protocol_v3_1_0.md
```

---

## 🔄 시스템 간 연계 흐름

```
[사용자 프롬프트 입력]
       │
       ▼
[UserPromptSubmit Hook]
  skill-activator.sh → 관련 스킬 추천
       │
       ▼
[Claude 작업 수행]
  - Agent 배분 (Primary Coordinator)
  - 스킬 참조하며 코드 작성
  - Dev Docs 참조하며 방향 유지
       │
       ▼
[PreCompact Hook]
  "Dev Docs에 진행상황 저장하세요!"
       │
       ▼
[PostCompact Hook]
  post-compact-reminder.sh → 스킬/Dev Docs 상태 안내
       │
       ▼
[세션 재시작]
  /resume → Dev Docs에서 컨텍스트 복원
```

---

*Generated for: Parallel Agents Safety Protocol v3.1.0 + Skills Activation + Dev Docs*
*Claude Code v2.1.78 환경 | 통합 시스템 v1.0*
