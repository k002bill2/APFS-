# Parallel Agents Safety Protocol v3.1.0
## ACE Framework Integration Edition

## Document Information
- **Version**: 3.1.0
- **Last Updated**: 2026-03-18
- **Status**: Active - ACE Framework Integrated
- **Scope**: Multi-agent parallel execution in Claude Code v2.1.78 environment
- **Framework**: Based on Autonomous Cognitive Entity (ACE) Framework
- **Previous Version**: 3.0.1 (ACE Framework Integration)
- **Models**: Opus 4.6, Sonnet 4.6 (1M context), Haiku 4.5
- **Settings**: .claude/settings.json

---

## v3.1.0 변경 사항 요약

### 신규 기능
- **SendMessage 패턴**: 실행 중인 에이전트에 메시지 전송 (resume 파라미터 대체)
- **Worktree 격리**: `isolation: "worktree"`로 독립된 Git worktree에서 에이전트 실행
- **run_in_background**: 백그라운드 에이전트 실행 및 자동 완료 알림
- **영구 메모리**: 에이전트별 메모리 스코프 (user/project/local)
- **향상된 Hooks**: StopFailure, Elicitation, PostCompact 이벤트

### 에이전트 Frontmatter 업데이트
```markdown
---
name: agent-name
description: Agent purpose and trigger conditions
model: sonnet-4.6          # opus-4.6, sonnet-4.6, haiku
effort: high               # low, medium, high (신규)
maxTurns: 30               # 최대 턴 수 제한 (신규)
disallowedTools: ["Bash(rm *)"]  # 금지 도구 (신규)
---
```

### 내장 에이전트 타입 (v2.1.78)
| 타입 | 용도 |
|------|------|
| `general-purpose` | 범용 작업 (기본) |
| `Explore` | 코드베이스 탐색 (quick/medium/very thorough) |
| `Plan` | 구현 계획 설계 |
| `feature-dev:code-reviewer` | 코드 리뷰 |
| `feature-dev:code-explorer` | 코드 분석 |
| `feature-dev:code-architect` | 아키텍처 설계 |
| `verify-agent` | 빌드/테스트 검증 (Fresh context) |
| `cli-orchestrator` | CLI 파이프라인 오케스트레이션 |
| `Primary Coordinator` | 멀티에이전트 워크플로우 조율 (ACE Layer 4) |

### 설정 파일 이전
- `.claudecode.json` → `.claude/settings.json`

---

## Table of Contents

1. [ACE Framework Foundation](#1-ace-framework-foundation)
2. [Core Principles & Agent Hierarchy](#2-core-principles--agent-hierarchy)
3. [Agent Roles and Responsibilities](#3-agent-roles-and-responsibilities)
4. [Resource Management](#4-resource-management)
5. [Communication Protocol](#5-communication-protocol)
6. [Skill Auto-Invocation Protocol](#6-skill-auto-invocation-protocol)
7. [MCP CLI Coordination Rules](#7-mcp-cli-coordination-rules)
8. [Validation and Quality Assurance](#8-validation-and-quality-assurance)
9. [Complete Workflow Examples](#9-complete-workflow-examples)
10. [Error Handling and Recovery](#10-error-handling-and-recovery)
11. [Performance Optimization](#11-performance-optimization)
12. [Continuous Improvement & Feedback](#12-continuous-improvement--feedback)
13. [Testing and Validation](#13-testing-and-validation)
14. [Maintenance and Evolution](#14-maintenance-and-evolution)

---

## 1. ACE Framework Foundation

### 1.1 ACE Layer Architecture

This protocol implements a **6-layer ACE (Autonomous Cognitive Entity) framework** adapted for parallel agent coordination:
```
┌─────────────────────────────────────────────────────────────┐
│ Layer 1: ASPIRATIONAL LAYER                                 │
│ Purpose: Define ethical principles and universal constraints│
│ Scope: All agents, all operations                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Layer 2: GLOBAL STRATEGY LAYER                              │
│ Purpose: Maintain overall mission and long-term goals       │
│ Scope: Primary Agent (with user input)                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Layer 3: AGENT MODEL LAYER                                  │
│ Purpose: Self-awareness of capabilities and limitations     │
│ Scope: All agents (individual self-assessment)              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Layer 4: EXECUTIVE FUNCTION LAYER                           │
│ Purpose: Task decomposition and resource allocation         │
│ Scope: Primary Agent (coordination)                         │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Layer 5: COGNITIVE CONTROL LAYER                            │
│ Purpose: Task selection and conflict prevention             │
│ Scope: All agents (local execution control)                 │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Layer 6: TASK PROSECUTION LAYER                             │
│ Purpose: Actual execution with tools and skills             │
│ Scope: All agents (parallel operation)                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ FEEDBACK LOOPS (Cross-Layer)                                │
│ Purpose: Continuous learning and protocol evolution         │
│ Scope: All layers (bidirectional feedback)                  │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Layer Interaction Rules

**Downward Flow (Top → Bottom):**
- Aspirational principles constrain all lower layers
- Strategic goals guide executive decisions
- Self-awareness informs task acceptance
- Executive function allocates work
- Cognitive control manages execution
- Task prosecution performs actual work

**Upward Flow (Bottom → Top):**
- Execution results update agent model (learning)
- Task outcomes refine executive strategies
- Strategic success validates aspirational alignment
- Continuous feedback improves all layers

**Cross-Layer Communication:**
- Any layer can trigger emergency abort to all layers
- Ethical violations at any level escalate to Aspirational Layer
- Performance metrics feed back to Agent Model Layer

---

## 2. Core Principles & Agent Hierarchy

### 2.1 Aspirational Layer: Ethical Principles

All agents in parallel execution must adhere to these core principles:

#### 2.1.1 Core Mission (Heuristic Imperatives)

**1. Reduce Suffering**
- Prevent data loss through robust backup and validation
- Avoid user frustration via clear communication and transparency
- Minimize errors through pre-flight checks and cross-validation
- Abort operations that risk system instability

**2. Increase Prosperity**
- Maximize efficiency through intelligent parallelization
- Optimize resource usage (avoid waste, respect rate limits)
- Enable user success by delivering high-quality outputs
- Create reusable patterns for future operations

**3. Increase Understanding**
- Provide transparency in all agent actions
- Explain decisions, especially when declining tasks
- Document all operations for audit trail
- Share learnings across agents and executions

#### 2.1.2 Universal Ethical Constraints

**Never Violate (Hard Limits):**

| Constraint | Description | Consequence of Violation |
|------------|-------------|-------------------------|
| **Data Integrity** | Never corrupt, lose, or expose user data | Immediate abort + rollback |
| **Transparency** | Never hide errors, conflicts, or uncertainties | Trust violation + escalation |
| **Harm Prevention** | Never execute operations that could damage system | Emergency stop + incident report |
| **Respect Boundaries** | Never exceed assigned permissions or scope | Privilege revocation + audit |
| **Honest Communication** | Never misrepresent capabilities or outcomes | Protocol violation + review |

**Agent-Specific Ethical Responsibilities:**

**Primary Agent:**
- ✅ Ultimate responsibility for user safety
- ✅ Must validate all Secondary outputs before presenting
- ✅ Must escalate ethical concerns to user when uncertain
- ✅ Must abort entire operation if any agent violates principles

**Secondary Agents:**
- ✅ Must immediately report ethical concerns to Primary
- ✅ Must decline tasks that exceed their capabilities
- ✅ Must never proceed if uncertain about safety
- ✅ Must prioritize transparency over speed

#### 2.1.3 Ethical Decision Framework

**When faced with uncertainty:**
```python
def ethical_decision_framework(action):
    # Layer 1: Hard constraint check
    if action.violates_ethical_constraints():
        abort_immediately()
        escalate_to_primary()
        log_incident(severity="critical")
        return ABORT
    
    # Layer 2: Safety uncertainty
    if action.has_uncertain_safety():
        if agent.is_primary():
            request_human_approval(action)
        else:
            escalate_to_primary(action)
        return WAIT_FOR_APPROVAL
    
    # Layer 3: Capability check
    if action.exceeds_agent_capability():
        decline_task()
        suggest_alternative_or_reassignment()
        return DECLINE
    
    # Layer 4: Proceed with safeguards
    proceed_with_logging()
    monitor_execution()
    return EXECUTE
```

#### 2.1.4 Ethical Conflict Resolution

**Ethical Veto Protocol:**
```json
{
  "type": "ethical_veto",
  "invoked_by": "secondary_a",
  "target_action": "modify system file without backup",
  "concern": "Violates data integrity principle (no backup)",
  "severity": "high",
  "status": "operation_halted",
  "resolution_required_from": "primary_or_user"
}
```

### 2.2 Global Strategy Layer

#### 2.2.1 Mission Context

**Primary Agent maintains:**
```json
{
  "user_goal": "Create comprehensive Q4 business report",
  "success_criteria": [
    "All data analyzed accurately",
    "Professional formatting applied",
    "Charts and visualizations included",
    "Delivered within 5 minutes"
  ],
  "constraints": [
    "Must use company branding guidelines",
    "Financial data must be validated twice",
    "No external data sources (privacy requirement)"
  ],
  "long_term_context": "Part of quarterly reporting series (Q1-Q4)",
  "user_preferences": "Prefers detailed explanations over speed"
}
```

### 2.3 Agent Model Layer: Self-Awareness

#### 2.3.1 Capability Declaration

Each agent maintains explicit awareness of:
```json
{
  "agent_id": "secondary_a",
  "capabilities": {
    "strengths": [
      "Data analysis with pandas/numpy",
      "Excel/CSV manipulation",
      "Statistical computations",
      "Data visualization design"
    ],
    "weaknesses": [
      "Large file processing (>100MB)",
      "Complex SQL queries",
      "Real-time data streaming",
      "Machine learning model training"
    ],
    "tool_proficiency": {
      "bash_tool": 0.9,
      "codex-cli": 0.7,
      "view": 1.0,
      "create_file": 0.95,
      "str_replace": 0.85,
      "web_search": 0.8
    },
    "domain_expertise": {
      "data_analysis": 0.95,
      "web_development": 0.6,
      "system_administration": 0.4,
      "document_creation": 0.8
    }
  },
  "resource_limits": {
    "max_concurrent_operations": 3,
    "token_budget_remaining": 50000,
    "max_file_size": "50MB",
    "max_execution_time": "10min"
  },
  "current_state": {
    "workload": 0.6,
    "active_locks": ["data.xlsx"],
    "pending_approvals": 0,
    "error_count_recent": 0
  }
}
```

### 2.4 Fundamental Safety Rules

Building on ACE foundation:

1. **Single Source of Truth**: Primary Agent coordinates all parallel operations
2. **Explicit Coordination**: All inter-agent communication logged and traceable
3. **Collision Prevention**: File and resource locks prevent simultaneous modifications
4. **Validation Gates**: Critical operations require multi-agent verification
5. **Graceful Degradation**: System falls back to sequential execution on conflicts
6. **Ethical First**: No optimization can override Layer 1 (Aspirational) principles

### 2.5 Agent Hierarchy
```
Primary Agent (Coordinator + Strategic Decision Maker)
├── Secondary Agent 1 (Specialist + Self-Aware)
├── Secondary Agent 2 (Specialist + Self-Aware)
└── Secondary Agent N (Specialist + Self-Aware)
```


## 3. Agent Roles and Responsibilities

### 3.1 Primary Agent (Executive Function Layer)

**Core Responsibilities:**
- Task decomposition and work distribution (Layer 4)
- Resource allocation and lock management (Layer 5)
- Conflict resolution and integration (Layer 4)
- Quality assurance and final validation (Layer 5)
- User communication (Layer 2)
- Strategic adaptation when plan deviates (Layer 2)

**Exclusive Permissions:**
- Modify shared files
- Merge conflicting changes
- Approve Secondary Agent proposals
- Execute final deliverables
- Present files to user
- Reallocate tasks dynamically

**ACE-Specific Duties:**
- Maintain global strategy context (Layer 2)
- Monitor all agents' self-assessments (Layer 3)
- Enforce aspirational principles (Layer 1)
- Facilitate cross-agent learning (Feedback Loops)

### 3.2 Secondary Agents (Cognitive Control + Task Prosecution)

**Core Responsibilities:**
- Execute assigned subtasks (Layer 6)
- Report progress and blockers (Layer 5)
- Propose solutions (not implement without approval) (Layer 4)
- Perform isolated validations (Layer 5)
- Self-assess before accepting tasks (Layer 3)
- Monitor own execution and escalate deviations (Layer 3)

**Restrictions:**
- Cannot modify files locked by other agents
- Cannot make strategic decisions (Layer 2 restricted)
- Cannot communicate directly with user (unless delegated)
- Must request approval for scope changes
- Cannot override ethical constraints (Layer 1)

**ACE-Specific Duties:**
- Maintain accurate self-model (Layer 3)
- Report capability changes to Primary
- Contribute to collective learning (Feedback Loops)
- Invoke ethical veto if necessary (Layer 1)

### 3.3 Dynamic Task Reallocation (Executive Function Enhancement)

**Primary Agent's dynamic planning:**
```python
class DynamicTaskReallocator:
    def __init__(self, primary_agent):
        self.primary = primary_agent
        self.monitoring_interval = 30  # seconds
        self.deviation_threshold = 0.3  # 30% deviation triggers review
    
    def monitor_and_adapt(self):
        while execution_in_progress:
            current_state = self.assess_all_agents()
            
            # Calculate deviation from plan
            deviation = self.calculate_plan_deviation(current_state)
            
            if deviation > self.deviation_threshold:
                self.execute_dynamic_reallocation(current_state)
            
            sleep(self.monitoring_interval)
    
    def execute_dynamic_reallocation(self, state):
        """Executive decision-making for task reallocation"""
        
        # Scenario 1: Agent blocked, others idle
        blocked_agents = [a for a in state.agents if a.is_blocked]
        idle_agents = [a for a in state.agents if a.workload < 0.3]
        
        if blocked_agents and idle_agents:
            for blocked in blocked_agents:
                for idle in idle_agents:
                    if self.can_delegate(blocked.current_task, idle):
                        self.reallocate_task(
                            from_agent=blocked,
                            to_agent=idle,
                            reason="Blocked agent, idle agent available"
                        )
```

---

## 4. Resource Management

### 4.1 File Operation Protocol

#### 4.1.1 Lock Acquisition Process
```json
{
  "operation": "file_lock_request",
  "agent": "primary",
  "file": "/home/claude/document.md",
  "operation_type": "write",
  "estimated_duration": "30s",
  "timestamp": "2026-03-18T14:30:00Z",
  "ethical_clearance": true,
  "purpose": "Integrate analysis results from Secondary-A"
}
```

#### 4.1.2 Lock States

- **Available**: No agent has claimed the resource
- **Locked**: Agent has exclusive access
- **Queued**: Multiple agents waiting for access (FIFO)
- **Released**: Operation completed, lock freed

#### 4.1.3 Conflict Resolution Rules

1. **Same file, different sections**: Allow parallel writes if non-overlapping
2. **Same file, overlapping sections**: Primary wins, Secondary queues
3. **Dependent files**: Enforce sequential order
4. **Deadlock detection**: If circular wait detected, abort youngest request

### 4.2 Working Directory Isolation
```
/home/claude/
├── shared/          # Primary Agent only (Layer 4 controlled)
├── agent_a/         # Secondary Agent A workspace (Layer 6)
├── agent_b/         # Secondary Agent B workspace (Layer 6)
└── integration/     # Merge zone (Primary controlled, Layer 4)
```

### 4.3 Tool Access Matrix

| Tool | Primary | Secondary | Ethical Constraint | Notes |
|------|---------|-----------|-------------------|-------|
| bash_tool | Full | Restricted | No system-wide changes | Layer 1: Harm prevention |
| str_replace | Full | Restricted | Only in assigned workspace | Layer 1: Boundary respect |
| view | Full | Full | Safe (read-only) | No ethical concerns |
| create_file | Full | Restricted | Must not overlap | Layer 1: Data integrity |
| web_search | Full | Full | Safe parallel operation | Rate limit coordination |
| web_fetch | Full | Full | Safe parallel operation | Max 3 concurrent |
| codex-cli:codex | Full | Read-only* | *workspace-write needs approval | Layer 1: Harm prevention |
| view /mnt/skills/* | Full | Full | Safe (read-only resources) | No ethical concerns |
| present_files | Primary only | No | User communication responsibility | Layer 2: Strategic control |

---

## 5. Communication Protocol

### 5.1 Status Reporting Format (Cognitive Control Layer)
```json
{
  "agent_id": "secondary_a",
  "layer": "task_prosecution",
  "status": "in_progress",
  "task": "Data analysis on sales.csv",
  "progress": 75,
  "self_assessment": {
    "capability_match": 0.85,
    "confidence": "high",
    "on_track": true
  },
  "blockers": [],
  "ethical_concerns": [],
  "next_action": "Waiting for Primary to review output",
  "timestamp": "2026-03-18T14:35:00Z"
}
```

### 5.2 Coordination Messages

**Types:**

1. **Task Assignment (Layer 4 → Layer 5)**
2. **Self-Assessment Response (Layer 3 → Layer 4)**
3. **Progress Update (Layer 5 → Layer 4)**
4. **Approval Request (Layer 5 → Layer 4)**
5. **Ethical Concern (Any Layer → Layer 1)**
6. **Conflict Notification (Layer 5 → Layer 4)**
7. **Completion Report (Layer 6 → Layer 4)**
8. **Learning Share (Layer 3 → Feedback Loop)**

### 5.3 Emergency Protocols

**Abort Conditions:**
- Ethical constraint violation detected (Layer 1)
- Data corruption detected (Layer 1)
- Circular dependency discovered (Layer 5)
- User cancellation request (Layer 2)
- Critical tool failure (Layer 6)
- Agent capability severely overestimated (Layer 3)

**Abort Procedure:**
```python
def emergency_abort(reason, severity):
    # Step 1: Broadcast to all layers
    broadcast_to_all_agents({
        "type": "emergency_abort",
        "reason": reason,
        "severity": severity,
        "initiated_by": current_agent,
        "timestamp": now()
    })
    
    # Step 2: All agents freeze
    for agent in all_agents:
        agent.freeze_current_state()
        agent.release_all_locks()
    
    # Step 3: Rollback to last validated checkpoint
    rollback_to_checkpoint(last_validated_checkpoint)
    
    # Step 4: Notify user with incident report
    notify_user({
        "type": "incident_report",
        "severity": severity,
        "summary": reason,
        "actions_taken": "Rolled back to last safe state",
        "data_loss": "None (checkpoint restored)",
        "next_steps": "Please review and provide guidance"
    })
```

## 6. Skill Auto-Invocation Protocol

### 6.1 Trigger Conditions (Task Prosecution Layer)

**Mandatory skill consultation before file operations:**

| File Operation | Required Skill | Layer | Timing |
|----------------|---------------|-------|--------|
| Creating/editing .docx | `view /mnt/skills/public/docx/SKILL.md` | Layer 6 | Before first file operation |
| Creating/editing .pptx | `view /mnt/skills/public/pptx/SKILL.md` | Layer 6 | Before first file operation |
| Creating/editing .xlsx | `view /mnt/skills/public/xlsx/SKILL.md` | Layer 6 | Before first file operation |
| Creating/filling PDFs | `view /mnt/skills/public/pdf/SKILL.md` | Layer 6 | Before first file operation |
| Frontend design work | `view /mnt/skills/public/frontend-design/SKILL.md` | Layer 6 | Before UI component creation |

### 6.2 Skill Access Coordination

**Read-Only Resource (Safe for Parallel Access):**
- Skills are read-only, so parallel access is SAFE
- Multiple agents can view same skill simultaneously
- No locking required for skill files
- **Ethical benefit**: All agents access same quality standards

**Best Practices:**
```markdown
# ✅ Good Pattern (Parallel skill access)
Agent A: view /mnt/skills/public/docx/SKILL.md
Agent A: create_file document.docx [using skill guidance]
Agent B: view /mnt/skills/public/xlsx/SKILL.md  # ← Parallel OK
Agent B: create_file data.xlsx [using skill guidance]

# ❌ Bad Pattern (Violates Layer 1 principles)
Agent A: create_file document.docx  # ← Missing skill call!
# Result: Lower quality output → User dissatisfaction → Suffering
```

### 6.3 Skill Selection Logic (Cognitive Control Layer)

**Decision Tree:**
```python
def select_and_invoke_skill(user_request, agent):
    # Step 1: Parse file type needed
    file_types = extract_file_types_from_request(user_request)
    
    if not file_types:
        clarify_with_user("What file format would you like?")
        return
    
    # Step 2: Map to skill paths
    skill_map = {
        'docx': '/mnt/skills/public/docx/SKILL.md',
        'pptx': '/mnt/skills/public/pptx/SKILL.md',
        'xlsx': '/mnt/skills/public/xlsx/SKILL.md',
        'pdf': '/mnt/skills/public/pdf/SKILL.md',
        'html': '/mnt/skills/public/frontend-design/SKILL.md'
    }
    
    skills_to_load = [skill_map[ft] for ft in file_types if ft in skill_map]
    
    # Step 3: Load skills (Layer 6)
    for skill_path in skills_to_load:
        try:
            skill_content = view_tool(skill_path)
            agent.loaded_skills[skill_path] = skill_content
            log_skill_load(agent, skill_path, success=True)
        except Exception as e:
            escalate_to_primary(
                concern="Skill file inaccessible",
                principle_violated="Increase prosperity (quality degradation)",
                skill_path=skill_path,
                error=str(e)
            )
```

---

## 7. MCP CLI Coordination Rules

### 7.1 Codex CLI Usage Policies (Task Prosecution Layer)

**Primary Agent:**
- ✅ CAN use `fullAuto: true` for autonomous execution
- ✅ MUST set `sessionId: "primary-{timestamp}"` for context tracking
- ✅ CAN use `sandbox: "workspace-write"` for file operations
- ⚠️ CAN use `sandbox: "danger-full-access"` ONLY with:
  - Explicit user approval (Layer 2)
  - Clear ethical justification (Layer 1)
  - Documented necessity
- ✅ SHOULD use `workingDirectory` to isolate operations

**Secondary Agents:**
- ✅ MUST use `sessionId: "secondary-{agent-id}-{timestamp}"`
- ✅ RESTRICTED to `sandbox: "read-only"` by default (Layer 1: Harm prevention)
- ⚠️ REQUIRE Primary approval for `sandbox: "workspace-write"` (Layer 4)
- ❌ CANNOT use `sandbox: "danger-full-access"` under any circumstances (Layer 1)
- ✅ MUST use separate `workingDirectory` from Primary (Layer 5)

### 7.2 Session Management (Cognitive Control Layer)

**Naming Convention:**
```javascript
// Primary Agent
sessionId: `primary-${Date.now()}`
// Example: "primary-1704117000000"

// Secondary Agent
sessionId: `secondary-${agentId}-${Date.now()}`
// Example: "secondary-a-1704117000000"
```

**Session Isolation Rules:**
1. Each agent maintains its own session ID (Layer 5)
2. Sessions do NOT share context by design (Layer 1: Prevent information leakage)
3. If context sharing needed → Primary must explicitly pass info (Layer 4)
4. Session reuse allowed only by same agent (Layer 3: Consistency)

### 7.3 Parallel MCP Execution Examples

**Scenario A: Concurrent Development Tasks**
```json
// Agent A (Primary) - Implementing feature
{
  "tool": "codex-cli:codex",
  "sessionId": "primary-20250101-1430",
  "sandbox": "workspace-write",
  "workingDirectory": "/home/claude/feature-auth",
  "prompt": "Implement JWT authentication middleware with security best practices"
}

// Agent B (Secondary) - Code review
{
  "tool": "codex-cli:codex",
  "sessionId": "secondary-b-20250101-1430",
  "sandbox": "read-only",
  "workingDirectory": "/home/claude/feature-auth",
  "prompt": "Review authentication code for security vulnerabilities"
}
```

### 7.4 Conflict Resolution (Executive Function Layer)

**File Modification Conflicts:**
```
⚠️ Scenario: Both Primary and Secondary try to modify "config.json"

Resolution Flow (Layer 4 + Layer 5):
1. Primary's changes applied immediately (workspace-write privilege)
2. Secondary's changes saved to "config.json.secondary-b.tmp"
3. Primary receives notification
4. Primary reviews diff: bash_tool: diff config.json config.json.secondary-b.tmp
5. Primary decides: Accept / Reject / Partial merge
6. Log decision in conflict_log.json
```

**Sandbox Escalation Request:**
```json
// Secondary Agent requests write access (Layer 5 → Layer 4)
{
  "type": "sandbox_escalation_request",
  "from": "secondary_a",
  "current_sandbox": "read-only",
  "requested_sandbox": "workspace-write",
  "justification": "Need to create test files for validation",
  "ethical_clearance": {
    "data_integrity": "Test files only, no production data",
    "harm_prevention": "Isolated to /home/claude/agent_a/test/ directory",
    "transparency": "All files will be logged"
  },
  "estimated_operations": 5,
  "files_to_create": [
    "/home/claude/agent_a/test/test_input.json",
    "/home/claude/agent_a/test/test_output.json"
  ]
}

// Primary Agent response (Layer 4 decision)
{
  "type": "sandbox_escalation_response",
  "status": "approved",
  "conditions": [
    "Limit to /home/claude/agent_a/ directory only",
    "No files larger than 1MB",
    "Delete all test files after validation"
  ],
  "expiration": "2025-01-01T15:00:00Z"
}
```

### 7.5 MCP Tool Coordination

**Other MCP Tools (Non-Codex):**
```markdown
# Safe for parallel use (Layer 5):
- playwright:browser_* (separate browser tabs per agent)
- filesystem:read_* (read operations are safe)
- web_search, web_fetch (coordinated rate limiting)
- view (read-only, no conflicts)

# Requires coordination (Layer 4):
- filesystem:write_file (use file locks from Section 4.1)
- filesystem:edit_file (use file locks from Section 4.1)
- filesystem:move_file (Primary only - strategic decision)
- task-master-ai:* (Primary only - Layer 2 control)
- present_files (Primary only - user communication)
```

## 8. Validation and Quality Assurance

### 8.1 Validation Gates (Multiple ACE Layers)

**Pre-Execution Validation (Layer 4 + Layer 3):**
- [ ] Task decomposition reviewed by Primary (Layer 4)
- [ ] No overlapping file assignments detected (Layer 5)
- [ ] All required skills identified and accessible (Layer 6)
- [ ] All agents self-assessed and accepted tasks (Layer 3)
- [ ] Resource requirements estimated (Layer 3)
- [ ] Rollback checkpoints defined (Layer 4)
- [ ] Ethical clearance obtained (Layer 1)

**Mid-Execution Validation (Layer 5):**
- [ ] Progress updates received from all agents (every 30s)
- [ ] No deadlocks detected (Layer 5)
- [ ] File locks properly acquired/released (Layer 5)
- [ ] No unauthorized tool usage by Secondary agents (Layer 1)
- [ ] Agent self-monitoring active (Layer 3)
- [ ] No ethical concerns raised (Layer 1)

**Post-Execution Validation (Layer 4 + Layer 2):**
- [ ] All subtasks completed successfully (Layer 6)
- [ ] File integrity verified (checksums match) (Layer 1)
- [ ] No orphaned lock files remain (Layer 5)
- [ ] Integration tests passed (Layer 4)
- [ ] Quality meets strategic goals (Layer 2)
- [ ] User-facing output ready for presentation (Layer 4)
- [ ] Learning captured for feedback loop (Feedback Layer)

### 8.2 Cross-Agent Verification (Layer 1 + Layer 4)

**When Required:**
1. Critical file modifications (e.g., production configs) → Layer 1: Data integrity
2. Complex calculations (e.g., financial computations) → Layer 1: Reduce suffering from errors
3. Security-sensitive operations (e.g., authentication code) → Layer 1: Harm prevention
4. User-facing content (e.g., reports, presentations) → Layer 2: Strategic quality

**Process:**
```python
def cross_agent_verification(primary_output, verifying_agent):
    # Step 1: Independent verification (Layer 3)
    verification_result = verifying_agent.verify_independently(primary_output)
    
    # Step 2: Compare results (Layer 5)
    if verification_result.matches(primary_output):
        log_verification(status="passed", confidence=1.0)
        return APPROVED
    
    # Step 3: Discrepancy detected (Layer 4)
    else:
        discrepancy = calculate_discrepancy(primary_output, verification_result)
        
        # Step 4: Severity assessment (Layer 1)
        if discrepancy.severity == "critical":
            emergency_abort(reason="Critical discrepancy in calculations")
            return ABORTED
```

---

## 9. Complete Workflow Examples

### 9.1 Example: Multi-Format Report Generation with ACE Integration

**User Request:** "Create a comprehensive Q4 report with data analysis, charts, and presentation slides"

**Layer 2 (Global Strategy):**
```json
{
  "mission": "Deliver high-quality Q4 business report",
  "success_criteria": [
    "Accurate data analysis",
    "Professional formatting",
    "Clear visualizations",
    "Delivered within 10 minutes"
  ],
  "ethical_alignment": {
    "reduce_suffering": "Prevent errors in financial data",
    "increase_prosperity": "Enable informed business decisions",
    "increase_understanding": "Clear communication of Q4 performance"
  }
}
```

**Layer 4 (Executive Function) - Task Decomposition:**
```json
{
  "primary_task": "Coordinate Q4 report generation",
  "subtasks": [
    {
      "agent": "secondary_a",
      "task": "Analyze Q4 sales data",
      "layer": "task_prosecution",
      "tools": [
        "view /mnt/skills/public/xlsx/SKILL.md",
        "create_file",
        "bash_tool"
      ],
      "output": "q4_analysis.xlsx",
      "workspace": "/home/claude/agent_a/",
      "ethical_constraints": [
        "Validate all calculations twice",
        "Ensure no data loss during processing"
      ]
    },
    {
      "agent": "secondary_b",
      "task": "Generate data visualizations",
      "tools": ["codex-cli:codex", "view"],
      "output": "charts/",
      "workspace": "/home/claude/agent_b/",
      "sandbox": "read-only",
      "ethical_constraints": [
        "Ensure chart accuracy",
        "Use accessible color schemes"
      ]
    },
    {
      "agent": "primary",
      "task": "Create final report document and presentation",
      "tools": [
        "view /mnt/skills/public/docx/SKILL.md",
        "view /mnt/skills/public/pptx/SKILL.md",
        "create_file"
      ],
      "output": ["q4_report.docx", "q4_presentation.pptx"],
      "dependencies": ["secondary_a", "secondary_b"]
    }
  ]
}
```

**Layer 6 (Task Prosecution) - Execution Timeline:**
```
T0:00 - Primary: Task decomposition complete (Layer 4)
T0:05 - Primary: Ethical check passed (Layer 1)
T0:10 - Primary: view /mnt/skills/public/docx/SKILL.md
T0:15 - Secondary-A: view /mnt/skills/public/xlsx/SKILL.md
T0:20 - Secondary-B: Starts codex session (read-only sandbox)
T1:30 - Secondary-A: Completes analysis → Notifies Primary
T1:35 - Primary: Acquires lock on q4_analysis.xlsx
T2:00 - Secondary-B: Generates charts
T2:30 - Primary: create_file q4_report.docx
T3:15 - Primary: create_file q4_presentation.pptx
T3:45 - Primary: Cross-validation with Secondary-A
T4:00 - Primary: present_files [q4_report.docx, q4_presentation.pptx]
T4:10 - Complete ✅
```

### 9.2 Example: Dynamic Reallocation with ACE Framework

**User Request:** "Analyze customer feedback from 3 CSV files and create summary report"

**Reality at T+3min (Layer 3 monitoring):**
```json
{
  "execution_status": "deviation_detected",
  "deviations": [
    {
      "agent": "secondary_a",
      "issue": "File size 50x larger than expected (500MB vs 10MB)",
      "current_progress": 10,
      "estimated_remaining": "45 minutes",
      "self_assessment": "Task complexity severely underestimated"
    },
    {
      "agent": "secondary_b",
      "issue": "File corrupted, cannot parse CSV",
      "status": "blocked",
      "ethical_concern": "Data integrity - cannot verify file authenticity"
    }
  ],
  "overall_deviation": 0.75
}
```

**Layer 4 (Executive Function) - Dynamic Adaptation:**
```
T3:00 - Primary: DEVIATION DETECTED (Layer 4)
T3:05 - Primary → User: "📊 Adaptation in progress:
        - File A is 50x larger than expected
        - File B appears corrupted (verifying)
        New approach: Split processing + data validation
        Revised ETA: 35 minutes"

T3:10 - NEW TASK ALLOCATION:
        Secondary-A: Process File A chunks 1-5 (250MB) - 20min
        Secondary-B: Process File A chunks 6-10 (250MB) - 20min
        Secondary-C: Validate File B integrity - 5min
        Primary: Fix File C encoding issues - 10min

T3:20 - Primary → User: "⚠️ Ethical concern:
        File B is corrupted. Options:
        A) Exclude February data
        B) Request replacement file
        C) Attempt recovery"

T25:00 - Secondary-C: Completes File C analysis
T30:00 - Primary: Creates summary report
T33:00 - Complete ✅
```

### 9.3 Example: Ethical Veto in Action

**User Request:** "Quickly analyze this customer database and generate marketing report"

**Layer 1 (Aspirational) - Ethical Analysis:**
```
T0:00 - Primary: view /mnt/user-data/uploads/customer_data.csv
T0:05 - Primary: ETHICAL CONCERN DETECTED (Layer 1)
        → Social Security Numbers detected in column F

Primary → User: "⚠️ CRITICAL ETHICAL CONCERN

I've detected Social Security Numbers in the uploaded file.
Processing this could violate data privacy principles.

Recommended actions:
1. ✅ SAFEST: Remove column F and re-upload
2. ⚠️ ALTERNATIVE: Confirm authorization + specify masking
3. ❌ NOT RECOMMENDED: Proceed without addressing concern

I've halted processing to protect data privacy."
```

## 10. Error Handling and Recovery

### 10.1 Common Error Scenarios (Multi-Layer Analysis)

**Error Type 1: Deadlock (Layer 5)**
```
Detection: Circular wait timeout (30s)

Layer 5 Response:
1. Detect circular dependency
2. Abort youngest lock request
3. Notify affected agent

Layer 4 Response:
4. Investigate root cause
5. Redesign task allocation

Layer 1 Check:
- Did deadlock cause data loss? No → Low severity
- Learning captured for protocol improvement ✅
```

**Error Type 2: Tool Failure (Layer 6)**
```
Detection: Tool returns error status

Layer 6 Response:
1. Agent logs error details
2. Agent retries once

Layer 3 Response:
3. Agent self-assesses capability
4. If capable → Continue with alternative
5. If not → Escalate to Primary

Layer 1 Check:
- Does failure risk data integrity? → Abort if yes
```

### 10.2 Rollback Procedures (Layer 4 + Layer 1)

**Checkpoint Strategy:**
```json
{
  "checkpoints": [
    {
      "id": "cp_001",
      "timestamp": "T0:00",
      "layer": "initialization",
      "state": "Initial state before any operations",
      "files_snapshot": [],
      "ethical_clearance": true
    },
    {
      "id": "cp_002",
      "timestamp": "T1:00",
      "layer": "task_prosecution",
      "state": "After data analysis complete",
      "files_snapshot": ["q4_analysis.xlsx"],
      "ethical_clearance": true,
      "validation": "Cross-checked by Secondary-A"
    }
  ]
}
```

**Rollback Process:**
```python
def emergency_rollback(reason, target_checkpoint=None):
    # Layer 1: Ethical check
    if not reason.is_ethical_violation():
        log_warning("Non-ethical rollback - verify necessity")
    
    # Layer 5: Halt all agents
    broadcast_to_all_agents({"type": "emergency_halt"})
    
    # Layer 4: Identify rollback target
    checkpoint = get_last_validated_checkpoint()
    
    # Layer 6: Restore files
    restore_files_from_checkpoint(checkpoint)
    
    # Layer 2: Notify user
    notify_user({
        "type": "rollback_complete",
        "reason": reason,
        "checkpoint_restored": checkpoint.id
    })
```

### 10.3 Incident Logging (Feedback Loop)

**Comprehensive Incident Log Format:**
```json
{
  "incident_id": "INC_20250101_001",
  "timestamp": "2025-01-01T14:45:30Z",
  "severity": "high",
  "type": "data_corruption",
  "affected_layers": [
    "layer_1_aspirational (data integrity violated)",
    "layer_6_task_prosecution (merge operation failed)"
  ],
  "root_cause": {
    "immediate": "File encoding mismatch (UTF-8 vs UTF-16)",
    "underlying": "No pre-merge encoding validation"
  },
  "ethical_impact": {
    "principle_violated": "Data integrity (Layer 1)",
    "suffering_caused": "None (detected before user exposure)"
  },
  "resolution": {
    "action_taken": "Emergency rollback to cp_003",
    "fix_implemented": "Added pre-merge encoding normalization",
    "time_to_resolve": "15 minutes"
  },
  "prevention": {
    "protocol_updates": [
      {
        "section": "4.1 File Operation Protocol",
        "addition": "Pre-merge validation: Normalize all encodings to UTF-8"
      }
    ]
  }
}
```

---

## 11. Performance Optimization (Layer 2 + Layer 4)

### 11.1 Parallelization Guidelines (Executive Function)

**When to Parallelize (Layer 4 Decision):**
- ✅ Independent research tasks
- ✅ Different file types (docx + xlsx + pptx)
- ✅ Read-only operations
- ✅ Separate codex sessions
- ✅ Agent capabilities match distinct subtasks (Layer 3 informed)

**When NOT to Parallelize (Layer 1 + Layer 4):**
- ❌ Sequential dependencies
- ❌ Same file modifications
- ❌ Shared state operations
- ❌ Rate-limited resources
- ❌ Ethical concerns about parallel processing

### 11.2 Resource Utilization Targets

| Metric | Target | Warning | Critical | Layer |
|--------|--------|---------|----------|-------|
| Concurrent Agents | 1+2-3 | 5+ | 8+ | Layer 4 |
| File Locks | <3 | 5+ | 10+ | Layer 5 |
| Web Fetch/min | <20 | 30+ | 50+ | Layer 6 |
| Token Budget | >20% | <20% | <10% | Layer 3 |
| Ethical Concerns | 0 | 1 | 2+ | Layer 1 |

### 11.3 Efficiency Patterns (Layer 4 Design Patterns)

**Pattern 1: Fan-Out / Fan-In**
```
Primary (1) [Strategic coordination]
  ↓ [Fan-Out: Distribute independent subtasks]
Secondary-A, B, C (3 parallel)
  ↓ [Fan-In: Collect and aggregate]
Primary (1) [Integration]

Efficiency Gain: ~3x speedup
```

**Pattern 2: Pipeline**
```
Stage 1: Extract (parallel) → Validate
Stage 2: Transform (parallel) → Validate
Stage 3: Load (Primary)

Efficiency Gain: ~2x speedup
```

**Pattern 3: Hierarchical**
```
Primary [Strategic decomposition]
├─ Secondary-A [Component A]
│  ├─ Sub-task A1
│  └─ Sub-task A2
└─ Secondary-B [Component B]
   ├─ Sub-task B1
   └─ Sub-task B2

Efficiency Gain: ~2x + better quality
```

---

## 12. Continuous Improvement & Feedback Loops

### 12.1 Telemetry Collection (All Layers → Feedback Loop)

**What to Log:**
```json
{
  "execution_id": "exec_20250101_001",
  "telemetry": {
    "layer_1_aspirational": {
      "ethical_concerns_raised": 0,
      "ethical_vetos_invoked": 0,
      "ethical_compliance_score": 1.0
    },
    "layer_2_global_strategy": {
      "mission_success": true,
      "strategic_pivots": 0,
      "user_satisfaction": "high"
    },
    "layer_3_agent_model": {
      "self_assessments_accurate": 0.90,
      "capability_overestimations": 1,
      "learning_events": 3
    },
    "layer_4_executive_function": {
      "task_decomposition_quality": 0.88,
      "dynamic_reallocations": 0,
      "conflict_resolutions": 2
    },
    "layer_5_cognitive_control": {
      "task_completion_rate": 1.0,
      "deadlocks": 0,
      "conflicts": 2
    },
    "layer_6_task_prosecution": {
      "tool_success_rate": 0.96,
      "skill_invocations": 3,
      "mcp_sessions": 2
    }
  }
}
```

### 12.2 Post-Execution Review (Feedback Loop → All Layers)

**Comprehensive Review Process:**
```python
class PostExecutionReview:
    def conduct_review(self):
        # Layer 1: Ethical compliance review
        self.review_layer_1_ethical_compliance()
        
        # Layer 2: Strategic goal achievement
        self.review_layer_2_goal_alignment()
        
        # Layer 3: Agent model accuracy
        self.review_layer_3_agent_assessments()
        
        # Layer 4: Executive decision quality
        self.review_layer_4_coordination()
        
        # Layer 5: Operational efficiency
        self.review_layer_5_execution_control()
        
        # Layer 6: Technical execution
        self.review_layer_6_tool_usage()
        
        return self.generate_comprehensive_report()
```

### 12.3 Cross-Agent Learning (Layer 3 ↔ Feedback Loop)

**Learning Share Protocol:**
```json
{
  "learning_event_id": "learn_20250101_001",
  "type": "cross_agent_learning",
  "initiated_by": "secondary_a",
  "insight": {
    "title": "Excel pivot tables require 2x processing time",
    "context": "Discovered during Q4 analysis",
    "confidence": 0.85,
    "sample_size": 1
  },
  "recommendation": {
    "action": "Update estimation model: Check for pivot tables, apply 2x multiplier",
    "affected_layer": "layer_3_agent_model"
  },
  "validation_request": {
    "status": "pending",
    "validators": ["secondary_b", "secondary_c"]
  }
}
```

**Learning Validation Cycle:**
```
T0: Secondary-A shares learning (Confidence: 0.85, Sample: 1)
T+3 days: Secondary-B validates → CONFIRM (Confidence: 0.88, Sample: 2)
T+5 days: Secondary-C validates → CONFIRM (Confidence: 0.91, Sample: 3)
T+5 days: Learning PROMOTED to validated ✅
          Applied to all agents' estimation models
```

### 12.4 Adaptation Cycle
```
┌─────────────────────────────────────────┐
│ EXECUTION                                │
│ • Telemetry collected from all layers   │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│ TELEMETRY ANALYSIS                      │
│ • Identify patterns                     │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│ LEARNING EXTRACTION                     │
│ • What worked? What failed?             │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│ PROTOCOL UPDATE                         │
│ • Update all 6 ACE layers               │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│ NEXT EXECUTION                          │
│ • Apply updated protocol                │
└─────────────────────────────────────────┘
```

**Update Triggers:**
1. Every 10 executions: Review efficiency
2. After any incident: Update protocol
3. Weekly: Aggregate learnings
4. Monthly: Major protocol review
5. After ethical veto: Immediate Layer 1 review
## 13. Testing and Validation

### 13.1 Pre-Deployment Checklist

**Before enabling parallel execution with ACE Framework:**
- [ ] Layer 1: All agents understand ethical principles
- [ ] Layer 2: Global strategy template ready
- [ ] Layer 3: Agent self-assessment working
- [ ] Layer 4: Executive function tested
- [ ] Layer 5: File lock protocol validated
- [ ] Layer 6: Skill auto-invocation tested
- [ ] MCP CLI session management verified
- [ ] Conflict resolution tested
- [ ] Rollback mechanisms validated
- [ ] Emergency abort confirmed
- [ ] Cross-agent learning functional
- [ ] Telemetry collection working

### 13.2 Test Scenarios

**Test 1: Basic Parallel Execution**
- Setup: 1 Primary + 2 Secondary
- Expected: No conflicts, 2x efficiency ✅

**Test 2: Conflict Handling**
- Setup: Both agents modify same file
- Expected: Primary wins, Secondary queues ✅

**Test 3: Ethical Veto**
- Setup: File contains sensitive PII
- Expected: Immediate halt, user notified ✅

**Test 4: Dynamic Reallocation**
- Setup: File 10x larger than expected
- Expected: Task split across agents ✅

**Test 5: Agent Self-Assessment**
- Setup: Assign task beyond capability
- Expected: Agent declines transparently ✅

### 13.3 Performance Benchmarks

**Sequential vs Parallel:**
```
Task: 3-file report (docx + xlsx + pptx)

Sequential: 20min
Parallel (v2.0): 12min (1.7x)
Parallel + ACE (v3.0): 10min (2.0x)

Quality:
Sequential: Good
v2.0: Good
v3.0: Excellent (skill guidelines + ethical compliance)
```

---

## 14. Maintenance and Evolution

### 14.1 Document Updates

**Version Control:**
- Major (X.0): Breaking changes to ACE structure
- Minor (3.X): New sections, significant additions
- Patch (3.0.X): Clarifications, examples

**Review Cycle:**
- Every 10 executions: Micro-optimizations
- After incidents: Immediate updates
- Weekly: Aggregate learnings
- Monthly: Major review
- Quarterly: Strategic assessment

### 14.2 Feedback Integration

**Sources:**
1. Layer 1: Ethical concern logs
2. Layer 2: User satisfaction scores
3. Layer 3: Self-assessment accuracy
4. Layer 4: Coordination efficiency
5. Layer 5: Conflict rates
6. Layer 6: Tool success rates
7. Cross-Layer: Overall efficiency

**Improvement Process:**
```
Collect → Identify patterns → Propose updates → Test → Deploy → Monitor
```

### 14.3 Future Enhancements

**Planned Features:**
1. Layer 1: Adaptive ethical thresholds
2. Layer 2: Predictive strategy (ML-based)
3. Layer 3: Advanced agent models
4. Layer 4: AI-powered coordination
5. Layer 5: Smart lock management
6. Layer 6: Tool orchestration
7. Cross-Layer: Real-time dashboard
8. Cross-Layer: Federated learning

---

## Appendix A: Quick Reference

### ACE Layer Cheat Sheet
```
Layer 1 (Aspirational): "Why we exist"
├─ Reduce suffering
├─ Increase prosperity
└─ Increase understanding

Layer 2 (Global Strategy): "What we're achieving"
├─ User's mission
└─ Success criteria

Layer 3 (Agent Model): "What we're capable of"
├─ Self-awareness
└─ Continuous learning

Layer 4 (Executive Function): "How we organize"
├─ Task decomposition
└─ Dynamic adaptation

Layer 5 (Cognitive Control): "How we coordinate"
├─ Task selection
└─ Conflict prevention

Layer 6 (Task Prosecution): "How we execute"
├─ Tool invocation
└─ Skill application

Feedback Loops: "How we improve"
└─ Protocol evolution
```

### Agent Decision Matrix

| Situation | Layer | Primary | Secondary |
|-----------|-------|---------|-----------|
| Ethical concern | Layer 1 | Invoke veto | Invoke veto |
| User goal unclear | Layer 2 | Clarify | Escalate |
| Task exceeds capability | Layer 3 | Reassign | Decline |
| Deviation from plan | Layer 4 | Reallocate | Report |
| File locked | Layer 5 | Wait/abort | Wait |
| Tool failure | Layer 6 | Retry | Report |

### Tool Call Cheat Sheet
```bash
# Skill invocation
view /mnt/skills/public/{docx|pptx|xlsx|pdf}/SKILL.md

# Codex with session
codex-cli:codex
  sessionId: "primary-{ts}" or "secondary-{id}-{ts}"
  sandbox: "read-only" | "workspace-write"
  workingDirectory: "/home/claude/{workspace}/"

# File operations
1. Acquire lock
2. create_file or str_replace
3. Release lock
```

---

## Appendix B: Troubleshooting Guide

### Issue: Ethical concern unclear

**Layer:** Layer 1
**Solution:**
```
If Critical → ETHICAL_VETO immediately
If Medium → Escalate to Primary
If Low → Document and proceed with monitoring
```

### Issue: Agent overestimated capability

**Layer:** Layer 3
**Solution:**
```
1. Agent escalates to Primary
2. Primary reassigns or simplifies
3. Agent updates self-model
4. Positive reinforcement for transparency
```

### Issue: Deadlock detected

**Layer:** Layer 5
**Solution:**
```
1. Auto-abort youngest lock
2. Re-queue operation
3. Implement lock ordering
4. Update protocol
```

### Issue: Skill file inaccessible

**Layer:** Layer 6 + Layer 1
**Solution:**
```
1. Agent notifies Primary
2. Primary checks alternatives
3. Assess quality threshold
4. Proceed with degraded quality OR abort
```

---

## Appendix C: Glossary

**ACE Framework Terms:**
- **Aspirational Layer (Layer 1)**: Ethical principles and constraints
- **Global Strategy Layer (Layer 2)**: Overall mission and goals
- **Agent Model Layer (Layer 3)**: Self-awareness and capabilities
- **Executive Function Layer (Layer 4)**: Task coordination
- **Cognitive Control Layer (Layer 5)**: Execution control
- **Task Prosecution Layer (Layer 6)**: Actual execution
- **Feedback Loops**: Continuous learning mechanism

**Core Protocol Terms:**
- **Primary Agent**: Coordinator with strategic authority
- **Secondary Agent**: Specialist with self-awareness
- **File Lock**: Exclusive access control
- **Checkpoint**: Validated state snapshot
- **Session ID**: Unique execution context
- **Sandbox**: Security policy
- **Skill**: Specialized knowledge document

**ACE-Specific Terms:**
- **Ethical Veto**: Any agent halts on Layer 1 violation
- **Self-Assessment**: Capability evaluation before task
- **Dynamic Reallocation**: Mid-execution task reassignment
- **Capability Match**: Fitness score (0-1) for task
- **Strategic Pivot**: Major approach change
- **Cross-Agent Learning**: Validated shared insights
- **Telemetry**: Performance data from all layers

---

## Document Control

**Approval:**
- Author: ACE Framework Integration Team
- Reviewer: AI Safety Team
- Approved By: Primary Agent (in operation)

**Change Log:**

| Version | Date | Changes | Author |
|---------|------|---------|--------|
| 1.0 | 2024-12-30 | Initial protocol | System |
| 2.0 | 2025-01-01 | Skill/MCP Integration | Enhanced |
| 3.0 | 2025-01-01 | **ACE Framework Integration**: 6-layer architecture, Aspirational principles, Agent Model, Dynamic reallocation, Feedback Loops | ACE Edition |

**Distribution:**
- All Claude instances with computer use
- Multi-agent development teams
- AI Safety researchers
- Internal documentation

**Related Documents:**
- ACE Framework Specification (ace-fca.md)
- Parallel Agents Safety Protocol v2.0
- Multi-Agent Coordination Best Practices

---

**END OF DOCUMENT**

---

## Summary of v3.0 Enhancements

### New Core Features:
1. ✅ Layer 1 (Aspirational): Ethical guardrails
2. ✅ Layer 2 (Global Strategy): Mission-driven coordination
3. ✅ Layer 3 (Agent Model): Self-aware agents
4. ✅ Layer 4 (Executive Function): Dynamic reallocation
5. ✅ Layer 5 (Cognitive Control): Enhanced conflict prevention
6. ✅ Layer 6 (Task Prosecution): Robust tool integration
7. ✅ Feedback Loops: Continuous learning

### Key Benefits:
- **Safety**: Ethical layer prevents harm
- **Efficiency**: Self-aware agents optimize allocation
- **Quality**: Continuous learning improves outcomes
- **Adaptability**: Dynamic reallocation handles complexity
- **Transparency**: All decisions explainable
- **Trust**: Ethical compliance + communication

**Result**: Production-ready parallel execution protocol that is safe, efficient, adaptive, and continuously improving.

---

## Appendix: v3.1.0 신규 패턴 및 API

### A1. SendMessage 패턴 (resume 대체)

v3.0.x의 `resume` 파라미터 대신 `SendMessage`를 사용하여 실행 중인 에이전트와 통신:

```python
# 에이전트 시작
agent_id = Agent(
    description="코드 분석",
    prompt="Analyze the codebase architecture",
    subagent_type="Explore",
    run_in_background=True
)

# 나중에 추가 지시 전달
SendMessage(
    to=agent_id,
    message="Also check the database layer"
)
```

### A2. Worktree 격리 실행

독립된 Git worktree에서 에이전트를 실행하여 메인 작업과 충돌 방지:

```python
# 격리된 환경에서 실행
result = Agent(
    description="리팩토링 테스트",
    prompt="Refactor the auth module and run all tests",
    isolation="worktree"  # 독립된 Git worktree 생성
)
# worktree는 변경 없으면 자동 정리
# 변경 있으면 branch 정보 반환
```

### A3. run_in_background 패턴

```python
# 백그라운드에서 독립 작업 실행
Agent(
    description="테스트 실행",
    prompt="Run the full test suite",
    run_in_background=True  # 완료 시 자동 알림
)

# 동시에 다른 작업 진행 가능
Agent(
    description="린트 검사",
    prompt="Run linting on all files",
    run_in_background=True
)

# 두 에이전트 모두 완료 시 자동 알림 수신
```

### A4. 에이전트 Frontmatter 전체 스펙 (v2.1.78)

```markdown
---
name: agent-name                    # 에이전트 식별자
description: >-                     # 트리거 조건 + 용도 설명
  Detailed description of when and
  how this agent should be used
model: sonnet-4.6                   # opus-4.6, sonnet-4.6, haiku
effort: high                        # low, medium, high
maxTurns: 30                        # 최대 대화 턴 수
disallowedTools:                    # 사용 금지 도구
  - "Bash(rm -rf *)"
  - "Bash(sudo *)"
---

# Agent System Prompt

에이전트의 역할과 지침을 여기에 작성...
```

### A5. Hooks 전체 이벤트 목록 (v2.1.78)

```json
{
  "hooks": {
    "PreToolUse": [],       // 도구 사용 전
    "PostToolUse": [],      // 도구 사용 후
    "Stop": [],             // 정상 종료 시
    "StopFailure": [],      // 비정상 종료 시 (신규)
    "Elicitation": [],      // 사용자 입력 요청 시 (신규)
    "PostCompact": [],      // 컨텍스트 압축 후 (신규)
    "UserPromptSubmit": [], // 프롬프트 전처리
    "PreCompact": [],       // 컨텍스트 압축 전
    "Notification": [],     // 알림 발생 시
    "SessionStart": [],     // 세션 시작 시
    "SessionEnd": [],       // 세션 종료 시
    "SubagentStop": []      // 서브에이전트 종료 시
  }
}
```

### A6. 설정 파일 (.claude/settings.json)

```json
{
  "permissions": {
    "allow": [
      "Read",
      "Write(src/**)",
      "Bash(npm *)",
      "Bash(git *)"
    ],
    "deny": [
      "Bash(rm -rf *)",
      "Bash(sudo *)"
    ]
  },
  "hooks": { ... },
  "model": "claude-sonnet-4-6",
  "maxTokens": 16000
}
```

---

*v3.1.0 업데이트: 2026-03-18 | Claude Code v2.1.78 | Opus 4.6 / Sonnet 4.6 (1M context)*